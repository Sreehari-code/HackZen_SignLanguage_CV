"""SignBridge application components."""
