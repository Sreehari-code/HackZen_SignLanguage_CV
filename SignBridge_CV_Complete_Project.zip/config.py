"""Application configuration loading and validation."""
from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class AppConfig:
    camera_index: int
    confidence_threshold: float
    stable_frames: int
    cooldown_seconds: float
    max_history: int
    model_path: Path
    model_url: str
    gesture_phrases: dict[str, str]


def load_config(path: str | Path) -> AppConfig:
    """Load JSON configuration and reject malformed/unsafe parameter values."""
    config_path = Path(path)
    try:
        data: Any = json.loads(config_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ValueError(f"Cannot load configuration '{config_path}': {exc}") from exc
    if not isinstance(data, dict):
        raise ValueError("Configuration root must be a JSON object.")
    phrases = data.get("gesture_phrases")
    if not isinstance(phrases, dict) or not phrases:
        raise ValueError("gesture_phrases must be a non-empty object.")
    if any(not isinstance(k, str) or not k.strip() or not isinstance(v, str) or not v.strip() for k, v in phrases.items()):
        raise ValueError("Each gesture mapping must have a non-empty category and phrase.")
    threshold = data.get("confidence_threshold", 0.65)
    stable_frames = data.get("stable_frames", 5)
    cooldown = data.get("cooldown_seconds", 1.25)
    camera = data.get("camera_index", 0)
    history = data.get("max_history", 12)
    if isinstance(threshold, bool) or not isinstance(threshold, (int, float)) or not 0 <= threshold <= 1:
        raise ValueError("confidence_threshold must be between 0 and 1.")
    if isinstance(stable_frames, bool) or not isinstance(stable_frames, int) or stable_frames < 1:
        raise ValueError("stable_frames must be a positive integer.")
    if isinstance(cooldown, bool) or not isinstance(cooldown, (int, float)) or cooldown < 0:
        raise ValueError("cooldown_seconds must be zero or greater.")
    if isinstance(camera, bool) or not isinstance(camera, int) or camera < 0:
        raise ValueError("camera_index must be a non-negative integer.")
    if isinstance(history, bool) or not isinstance(history, int) or history < 1:
        raise ValueError("max_history must be a positive integer.")
    url = data.get("model_url")
    if not isinstance(url, str) or not url.startswith("https://"):
        raise ValueError("model_url must be an HTTPS URL.")
    raw_model_path = data.get("model_path", "models/gesture_recognizer.task")
    if not isinstance(raw_model_path, str) or not raw_model_path.strip():
        raise ValueError("model_path must be a non-empty path string.")
    return AppConfig(camera, float(threshold), stable_frames, float(cooldown), history,
                     (config_path.parent / raw_model_path).resolve(), url, dict(phrases))
