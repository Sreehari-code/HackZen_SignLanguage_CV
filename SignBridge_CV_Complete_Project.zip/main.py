"""SignBridge: real-time hand gesture communication demo."""
from __future__ import annotations

import argparse
import logging
import platform
import sys
import time
from pathlib import Path

import cv2

from src.camera import open_camera
from src.config import load_config
from src.gesture_recognition import GestureRecognizer, ensure_model
from src.sentence_manager import SentenceManager
from src.speech import SpeechWorker
from src.ui import render

ROOT = Path(__file__).resolve().parent
LOG = logging.getLogger("signbridge")


def parse_args():
    parser = argparse.ArgumentParser(description="SignBridge gesture-to-phrase demo")
    parser.add_argument("--config", type=Path, default=ROOT / "config.json", help="Path to configuration JSON")
    parser.add_argument("--check", action="store_true", help="Validate configuration and component imports without opening a camera")
    return parser.parse_args()


def main() -> int:
    logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")
    args = parse_args()
    if sys.version_info < (3, 10):
        LOG.error("Python 3.10 or newer is required; Python 3.11 is recommended.")
        return 2
    try:
        config = load_config(args.config)
    except ValueError as exc:
        LOG.error("%s", exc)
        return 2
    manager = SentenceManager(config.gesture_phrases, config.confidence_threshold,
                              config.stable_frames, config.cooldown_seconds, config.max_history)
    if args.check:
        LOG.info("Configuration valid: %d gesture mappings; Python %s on %s", len(config.gesture_phrases),
                 platform.python_version(), platform.system())
        return 0
    if platform.system() != "Windows":
        LOG.warning("This demo targets Windows; camera/audio behavior may differ on %s.", platform.system())
    if sys.version_info[:2] not in ((3, 11), (3, 13)):
        LOG.warning("Python 3.11 or 3.13 is recommended; running under %s.", platform.python_version())

    camera = recognizer = speech = None
    try:
        try:
            model = ensure_model(config.model_path, config.model_url)
            recognizer = GestureRecognizer(model)
        except Exception as exc:
            LOG.error("Gesture recognizer unavailable. Check the model file and internet connection: %s", exc)
            return 2
        try:
            camera = open_camera(config.camera_index)
        except RuntimeError as exc:
            LOG.error("%s", exc)
            return 2
        speech = SpeechWorker()
        cv2.namedWindow("SignBridge | Real-Time Hand Gesture Communication", cv2.WINDOW_NORMAL)
        cv2.resizeWindow("SignBridge | Real-Time Hand Gesture Communication", 1120, 780)
        show_help, show_landmarks = True, True
        category, confidence, phrase = "", 0.0, ""
        recognition_status = "Recognition active"
        last_recognition_error = ""
        previous_frame_time = time.perf_counter()
        fps = 0.0
        while True:
            ok, frame = camera.read()
            if not ok:
                recognition_status = "Camera frame unavailable; check camera connection/permissions"
                break
            frame = cv2.flip(frame, 1)
            rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            try:
                result = recognizer.recognize(rgb)
                if result.gestures and result.gestures[0]:
                    prediction = result.gestures[0][0]
                    category, confidence = prediction.category_name, float(prediction.score)
                    phrase = config.gesture_phrases.get(category, "")
                    accepted = manager.observe(category, confidence)
                    if accepted:
                        LOG.info("Added phrase: %s", accepted)
                    recognition_status = "Recognition active" if phrase else "Gesture is not in configured vocabulary"
                    if confidence < config.confidence_threshold:
                        recognition_status = "Confidence below configured threshold"
                else:
                    category, confidence, phrase = "", 0.0, ""
                    manager.observe(None, 0.0)
                    recognition_status = "Show one hand to the camera"
                if show_landmarks:
                    recognizer.draw_landmarks(frame, result)
            except Exception as exc:
                category, confidence, phrase = "", 0.0, ""
                recognition_status = f"Recognition error: {exc}"
                # Log the first failure only: a missing/changed API should not
                # flood the terminal once per camera frame.
                if recognition_status != last_recognition_error:
                    LOG.exception("Frame recognition failed")
                    last_recognition_error = recognition_status
            else:
                last_recognition_error = ""
            now = time.perf_counter()
            elapsed = now - previous_frame_time
            if elapsed > 0:
                instant = 1 / elapsed
                fps = instant if fps == 0 else .85 * fps + .15 * instant
            previous_frame_time = now
            view = render(frame, category=category, confidence=confidence, phrase=phrase,
                          sentence=manager.sentence, history=list(manager.history),
                          camera_status=f"CAMERA {config.camera_index} • CONNECTED",
                          recognition_status=recognition_status, speech_status=speech.status, fps=fps,
                          show_help=show_help)
            cv2.imshow("SignBridge | Real-Time Hand Gesture Communication", view)
            key = cv2.waitKey(1) & 0xFF
            if key in (ord("q"), 27):
                break
            if key == ord("c"):
                manager.clear()
            elif key in (8, 127):
                manager.undo()
            elif key == ord("s"):
                speech.speak(manager.sentence)
            elif key == ord("h"):
                show_help = not show_help
            elif key == ord("l"):
                show_landmarks = not show_landmarks
    except cv2.error as exc:
        LOG.error("OpenCV window/camera error: %s", exc)
        return 2
    except KeyboardInterrupt:
        LOG.info("Interrupted; shutting down.")
    finally:
        if camera is not None:
            camera.release()
        if recognizer is not None:
            recognizer.close()
        if speech is not None:
            speech.close()
        cv2.destroyAllWindows()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
