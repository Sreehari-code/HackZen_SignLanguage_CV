# SignBridge: Real-Time Hand Gesture Communication System

SignBridge is a webcam-based computer-vision demo that recognizes a small set of MediaPipe hand gesture categories, maps them to configurable phrases, builds a sentence, and can speak that sentence using offline text-to-speech.

> **Prototype limitation:** This is a limited gesture-to-phrase prototype, not a complete sign-language translator. Its demonstration mappings are not universal or authoritative translations.

## Problem and features

The project demonstrates how camera-based hand tracking can offer an alternate way to create short spoken or written phrases. It provides a mirrored live feed, hand landmarks, gesture/confidence feedback, stable prediction and duplicate suppression, a sentence and history, undo/clear, requested speech, and keyboard controls.

## Technology and architecture

- Python 3.13 64-bit tested in the current workspace; Python 3.11 64-bit is also supported; Windows 10/11 target.
- MediaPipe Tasks Gesture Recognizer, OpenCV, NumPy, and pyttsx3.
- `main.py` coordinates the loop; `src/camera.py` opens the camera; `src/gesture_recognition.py` downloads/loads the Tasks model and draws landmarks; `src/sentence_manager.py` handles phrase state; `src/speech.py` serializes non-blocking speech; `src/ui.py` renders the HUD; `src/config.py` validates configuration.

Data flow: mirrored camera frame → RGB image → MediaPipe Tasks video recognizer → category/confidence/landmarks → threshold and stable-frame gate → phrase and sentence manager → HUD and optional speech worker.

## Requirements and setup

Use 64-bit Python 3.13 or 3.11. The current pins use MediaPipe 1.1.0, which is available for Python 3.13 and includes the modern Tasks API. Check your active version:

```powershell
python --version
```

Recommended quick launch: double-click `run_windows.bat`. It creates `.venv`, installs `requirements.txt`, and launches the app. It does not install Python or change system settings.

Manual PowerShell setup:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
python main.py
```

If PowerShell blocks activation, use a temporary process-only policy in that PowerShell window: `Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass`. It does not persist after the window closes. You may also launch `.venv\Scripts\python.exe main.py` without activation.

If you specifically use Python 3.11, replace the first command with `py -3.11 -m venv .venv`. If `.venv` already exists from another Python version or dependency installation failed partway, remove it and recreate it before reinstalling: `Remove-Item -Recurse -Force .venv`.

The MediaPipe model requires internet on first run unless it is already present at `models/gesture_recognizer.task`. Only the HTTPS URL configured in `config.json` is fetched; the model is reused on later runs. Camera access is needed for the interactive app. To validate configuration/imports without opening a camera, run `python main.py --check`.

## Use and controls

Show one hand clearly in the mirrored video and hold a gesture steady. The category, confidence, mapped phrase, approximate FPS, current sentence, recent history, camera, recognition, and speech status are shown in the window.

| Key | Action |
|---|---|
| Q or Esc | Exit and release resources |
| C | Clear sentence and history |
| S | Speak the complete current sentence |
| Backspace | Undo the most recent phrase |
| H | Show or hide help |
| L | Show or hide landmarks |

## Demonstration vocabulary

| MediaPipe category | Example phrase |
|---|---|
| Open_Palm | HELLO |
| Closed_Fist | STOP |
| Thumb_Up | YES |
| Thumb_Down | NO |
| Victory | PEACE |
| Pointing_Up | I HAVE A QUESTION |
| ILoveYou | I LOVE YOU |

These are configurable demo mappings, not claims about universal sign-language meaning. Edit `gesture_phrases` in `config.json`; keys must match MediaPipe category names. The same file configures `camera_index`, `confidence_threshold` (0–1), `stable_frames` (consecutive qualifying frames), `cooldown_seconds` (repeat wait for a held phrase), `max_history`, and model URL/path. An unknown category or below-threshold result is not appended. A different gesture can be accepted immediately; the same held phrase becomes eligible after its cooldown.

## Model details

The default model URL is the MediaPipe Gesture Recognizer float16 task model. The app saves it under `models/`, enforces HTTPS, uses a temporary file during download, and limits downloads to 100 MB. Keep `models/` out of source control; the model can be fetched when needed.

## Tests

Run unit tests without a webcam:

```powershell
python -m unittest discover -s tests -v
python -m compileall -q main.py src tests
```

The tests cover phrase addition, unknown gestures, duplicate/cooldown behavior, clear/undo, confidence, stability, mapping and invalid configuration. `python main.py --check` checks config and component imports without opening a camera.

## Troubleshooting

See [docs/TROUBLESHOOTING.md](docs/TROUBLESHOOTING.md) for camera permission/busy state, model download, recognition confidence, PowerShell, audio, and configuration help. See [docs/DEMO_SCRIPT.md](docs/DEMO_SCRIPT.md) for a 90-second presentation and [docs/PROJECT_OVERVIEW.md](docs/PROJECT_OVERVIEW.md) for the component summary.

## Limitations, ethics, and accessibility

The pretrained recognizer supports a limited set of static categories and is sensitive to camera angle, lighting, skin/background contrast, hand size, and individual variation. A short phrase mapping does not capture grammar, facial expression, two-handed signs, motion, regional variation, or the meaning and context of sign languages. A real sign-language translation system needs a properly defined language and vocabulary, appropriate and representative datasets, temporal recognition where signs require it, and validation with sign-language users or qualified interpreters. Involve the communities affected in design and evaluation; do not present this demo as a substitute for interpreters or as a dependable high-stakes communication aid. Camera frames are processed locally and are not saved by this app; the model is downloaded once from the configured URL.

## Future improvements

Potential next steps include selectable camera devices, configurable phrase editing in the UI, a richer temporal model trained and validated for a defined sign language, accessibility-focused user testing, and packaging after compatibility testing on supported Windows machines.
