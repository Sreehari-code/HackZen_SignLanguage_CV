# Troubleshooting

- **Python version:** use 64-bit Python 3.13 (tested here) or 3.11. Confirm with `python --version` or `py -0p`. The launcher deliberately does not install Python.
- **`No matching distribution found for mediapipe==0.10.21`:** requirements now pin MediaPipe 1.1.0, available for the current Python 3.13 package index. Delete the old `.venv`, recreate it using the Python you intend to run, then install the updated requirements.
- **`No module named cv2`:** dependency installation did not finish, or the app was started using a different interpreter than the one used by pip. Activate `.venv`, run `python -m pip install -r requirements.txt`, then check `python -c "import cv2, mediapipe; print(cv2.__version__, mediapipe.__version__)"` before launching. MediaPipe installs `opencv-contrib-python`, which provides `cv2`; do not install a separate OpenCV wheel alongside it.
- **PowerShell blocks activation:** run `Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass` in that PowerShell window only, then activate `.\.venv\Scripts\Activate.ps1`. This change ends when the window closes.
- **No camera / camera busy:** quit video-call or camera applications, connect the webcam, allow desktop apps under Windows camera privacy settings, and set `camera_index` in `config.json` (try 1 for a second camera).
- **Model download fails:** first launch needs internet access to the configured HTTPS model URL. Check network/proxy access, then rerun. The file is stored under `models/gesture_recognizer.task` and is reused locally.
- **No hand detected:** improve front lighting, place one hand fully in view, and avoid a cluttered background.
- **No phrases added:** hold a gesture steadily, check confidence and `confidence_threshold`, or lower `stable_frames` in `config.json`.
- **Speech unavailable:** install requirements and check that Windows has a usable audio output and speech voice. Recognition remains usable without speech.
- **Window/backend issues:** update the webcam driver and avoid other OpenCV builds in the same environment; use the supplied pinned requirements in a clean virtual environment.
- **Configuration error:** validate JSON syntax and parameter ranges. Gesture mapping keys must match MediaPipe category spelling exactly.
