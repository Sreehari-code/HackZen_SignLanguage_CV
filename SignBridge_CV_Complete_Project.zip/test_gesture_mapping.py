import json
import tempfile
import unittest
from pathlib import Path

from src.config import load_config
from src.sentence_manager import SentenceManager


class GestureMappingTests(unittest.TestCase):
    def test_loads_configuration_and_mapping(self):
        config = load_config(Path(__file__).parents[1] / "config.json")
        self.assertEqual(config.gesture_phrases["Open_Palm"], "HELLO")
        self.assertTrue(config.model_path.name.endswith(".task"))

    def test_invalid_threshold_is_rejected(self):
        source = json.loads((Path(__file__).parents[1] / "config.json").read_text(encoding="utf-8"))
        source["confidence_threshold"] = 1.5
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "bad.json"
            path.write_text(json.dumps(source), encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "confidence_threshold"):
                load_config(path)

    def test_mapping_phrase_is_used(self):
        manager = SentenceManager({"Open_Palm": "WELCOME"}, 0.4, 1, 1.0)
        self.assertEqual(manager.observe("Open_Palm", 0.8, 0), "WELCOME")


if __name__ == "__main__":
    unittest.main()
