# Project overview

SignBridge is a real-time, single-hand gesture-to-phrase demonstration. OpenCV captures and mirrors webcam frames, MediaPipe Tasks Gesture Recognizer returns hand landmarks and a built-in category, a stability gate accepts configured phrases, and a separate sentence manager tracks the current sentence and recent history. An optional worker thread sends requested sentences to offline pyttsx3 speech.

The interface uses an OpenCV resizable window and HUD to keep installation small. `config.json` contains the demonstration vocabulary, threshold, stability frame count, cooldown, camera index, and local model location. The model is downloaded from the configured HTTPS MediaPipe storage URL the first time the recognizer is launched.

This is not a complete sign-language translator. Real translation needs a defined language and vocabulary, suitable datasets, temporal modeling for signs that depend on motion, and validation with sign-language users or qualified interpreters.
